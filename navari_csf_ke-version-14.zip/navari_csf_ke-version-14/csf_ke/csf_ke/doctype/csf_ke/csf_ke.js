// Copyright (c) 2022, Navari Limited and contributors
// For license information, please see license.txt

frappe.ui.form.on('CSF KE', {
	// refresh: function(frm) {

	// }
});
