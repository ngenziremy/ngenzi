# Copyright (c) 2022, Navari Limited and Contributors
# See license.txt

# import frappe
import unittest

class TestCSFKE(unittest.TestCase):
	pass
