# Copyright (c) 2022, Navari Limited and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class CSFKE(Document):
	pass
